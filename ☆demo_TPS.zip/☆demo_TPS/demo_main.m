clc;clear
close all;
addpath('JCAS');
load Indian_pines_gt;load IndiaP;
t1 = clock;
data = img;GroundT = GroundT';
gth  = indian_pines_gt;
[no_lines,no_rows,no_bands] = size(data);
im_2d = reshape(data,size(data,1)*size(data,2),size(data,3))';
[im_2d] = scale_new(im_2d);

superpixel_data =reshape(compute_mapping(im_2d','PCA',54),size(data,1),size(data,2),54);
P{1} = [-1,1];P{2} = [-1,0,1];P{3} = [-1;1];P{4} = [-1;0;1];
dim_1 = 1:3;f_size  = 5;K = 10;MaxIter = 4;img = cell(1,18);
if ~exist('precess_image.mat','file')
    disp('There is not the processing_image file')
parfor dim = 1:18
    in_image = superpixel_data(:,:,dim_1+(dim-1)*3);
    in_image = padarray(in_image,[1 1]*6,'symmetric','both');
    for a = 1:4
        in_image = edgetaper(in_image,fspecial('gaussian',6,1));
    end
    iter = 1;T = zeros(size(in_image));PreS = zeros(size(in_image));
    alpha = 0.05;            gamma = 0.2;
    while(iter<MaxIter)
        [A,S]=AnalysisSC_Color( in_image-T, P, alpha,1,300);
        difference = mean((PreS(:)-S(:)).^2);
        PreS = S;
        if (iter==1)
            D = InitDict_Color( in_image-S, f_size, K );
        end
        [Z, T] = SynthesisSC_Color( in_image-S, D, gamma, 1, 300 );
        D   = UpdateFilter_Color( in_image-S, single(Z), D, f_size, K, 250 );
        iter = iter+1;
        if(difference<1e-10)
            iter = MaxIter+1;
        end
    end
    img1 = PreS((7:151),(7:151),:);
    img{dim} = img1;
disp(dim)
end
    save precess_image img
else
    disp('The processing_image file is ready.')
    load precess_image
end

img_1 = [];
for i = 1:18
    img_1 = cat(3,img_1,img{i});
end
clear img;img = img_1;
img = double(gather(img));
t2 = clock;
time(1,1) = etime(t2,t1);
%% 
for num = 1:10
    result = [];Result=[];
    indexes=train_test_random_new(GroundT(2,:));
    no_bands=size(img,3);
    fimg=double(reshape(img,[no_lines*no_rows no_bands]));
    [fimg] = scale_new(fimg);    fimg = fimg';
    train_SL = GroundT(:,indexes);
    train_samples = fimg(:,train_SL(1,:))';
    train_labels= train_SL(2,:)';
    test_SL = GroundT;
    test_SL(:,indexes) = [];
    test_samples = fimg(:,test_SL(1,:))';
    test_labels = test_SL(2,:)';
    [train_samples,M,m] = scale_func(train_samples);
    [fimg ] = scale_func(fimg',M,m);
    [Ccv Gcv cv cv_t] = cross_validation_svm(train_labels,train_samples);
    GroudTest = double(test_labels(:,1));
    %% linear kernel
    parameter = sprintf('-c %f -g %f -m 500 -t 0 -q',Ccv,Gcv);    %-t 0   linear kernel
    model = svmtrain(train_labels,train_samples,parameter);
    Result_linear = svmpredict(ones(no_lines*no_rows,1),fimg,model);
    ResultTest = Result_linear(test_SL(1,:));
    [OA_linear,AA_linear,kappa_linear,CA_linear] = confusion(GroudTest,ResultTest);
    oa_linear(num) = OA_linear; aa_linear(num) = AA_linear; k_linear(num) = kappa_linear;  ca_linear(:,num)= CA_linear; disp(oa_linear)
    result = cat(2,result,Result_linear);
    ppMLRprmap = reshape(Result_linear,no_lines,no_rows);
    ppMLRprmap_1 = label2color(ppMLRprmap,'india');
    figure(),imshow(ppMLRprmap_1)
    %% polynomial kernel
    parameter = sprintf('-c %f -g %f -m 500 -t 1 -q',Ccv,Gcv);    %-t 1   ploy kernel
    model = svmtrain(train_labels,train_samples,parameter);
    Result_poly = svmpredict(ones(no_lines*no_rows,1),fimg,model);
    ResultTest = Result_poly(test_SL(1,:));
    [OA_poly,AA_poly,kappa_poly,CA_poly] = confusion(GroudTest,ResultTest);
    oa_poly(num) = OA_poly; aa_poly(num) = AA_poly; k_poly(num) = kappa_poly;  ca_poly(:,num) = CA_poly;disp(oa_poly)
    result = cat(2,result,Result_poly);
    %% RBF kernel
    parameter=sprintf('-c %f -g %f -m 500 -t 2 -q',Ccv,Gcv);     %-t 2   RBF kernel
    model=svmtrain(train_labels,train_samples,parameter);
    Result_rbf = svmpredict(ones(no_lines*no_rows,1),fimg,model);
    ResultTest = Result_rbf(test_SL(1,:));
    [OA_rbf,AA_rbf,kappa_rbf,CA_rbf] = confusion(GroudTest,ResultTest);
    oa_rbf(num) = OA_rbf; aa_rbf(num) = AA_rbf; k_rbf(num) = kappa_rbf;ca_rbf(:,num) = CA_rbf;  disp(oa_rbf)
    result = cat(2,result,Result_rbf);
    %% multipli kernel decision
    for i = 1: no_lines*no_rows
        table=[];
        if result(i,1)~=result(i,2)&&result(i,2)~=result(i,3)&&result(i,1)~=result(i,3)
            Result(i) = result(i,2);
        else
            table = tabulate(result(i,:));
            [~,a] = max(table,[],1);
            Result(i) = a(3);
        end
    end
    Result = Result';
    ResultTest = Result(test_SL(1,:));
    [OA,AA,kappa,CA,confu] = confusion(GroudTest,ResultTest);
    oa(num) = OA;    aa(num) = AA;    k(num) = kappa;  ca(:,num) = CA; disp(oa) 
    t3 = clock;
    time(1,2) = etime(t3,t2);
end

