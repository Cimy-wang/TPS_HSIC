function [indexes]=train_test_random_new(y)

K = max(y);
indexes = [];
indexes_c=[];

% Value=[10,143,83,34,48,23,2,28,2,150,246,60,21,127,35,10]';
% Value=[10,143,83,34,48,23,2,28,2,150,246,60,21,127,35,10]';
% Value=[3,14,8,3,6,7,2,5,2,10,24,6,2,13,4,3]';
Value = [2,14,8,2,5,7,2,5,3,10,25,6,2,13,4,2]';
% Value = [6 6 6 6 6 6 6 6 6 6 6 6 6 6 6 6]';
% Value = Value/2;
% Value = [10 10 10 10 10 10 10 10 10 10]';
% Value = Value*10;
% Value = [12,12,12,12,12,12,12,12,13,13,13,13,13,13,13,13]';
for i=1:K
    index1 = find(y == i);
    per_index1 = randperm(length(index1));   %%%randperm Ϊ�������һ����������  randperm(5)  = 2 4 1 5 3
%     indexes_c = [indexes_c;index1(per_index1(1:Value(i))'];
     Number=per_index1(1:Value(i));
     indexes_c=[indexes_c index1(Number)];
     
end  
indexes = indexes_c(:);







% indexes = indexes';
% train = y(indexes);
% y(indexes) = [];
% test = y;

% for k_iter = 1:K
%     index_k = y == k_iter;
%     index_k = find(index_k);
%     if length(index_k) > n
%         index_k_random =  ceil(length(index_k).*rand(n,1));
%         index_k_random = sort(index_k_random);
%         index_k_random1 = [index_k_random(2:n);index_k_random(1)];
%         resid = index_k_random1 - index_k_random;
%         resid0 = resid == 0;
%         index_k_random(resid0) = [];
%         train_k = alltrain(:,index_k(index_k_random));
%         yindex = [yindex,index_k(index_k_random)];
%     else
%         n1 = ceil(length(index_k)/2);
%         index_k_random =  ceil(length(index_k).*rand(n1,1));
%         index_k_random = sort(index_k_random);
%         index_k_random1 = [index_k_random(2:n1);index_k_random(1)];
%         resid = index_k_random1 - index_k_random;
%         resid0 = resid == 0;
%         index_k_random(resid0) = [];
%         train_k = alltrain(:,index_k(index_k_random));
%         yindex = [yindex,index_k(index_k_random)];
%     end
%     train = [train,train_k];
% end
% 
% trainold = alltrain;
% alltrain(:,yindex) = [];
% test = alltrain;
% for i = 1:K
%     ly = length(find(y==i));
%     nf = ceil(pK*ly);
%     f = lys + ceil(ly.*rand(nf,1));
%     f = sort(f);
%     findex = [];
%     for j = 1:(length(f)-1)
%         if f(j) == f(j+1)
%             findex = [findex,j];
%         end
%     end
%     f(findex) = [];
%     train10 = alltrain(:,f);
%     yindex = [yindex,f'];
%     train = [train,train10];
%     lys = lys + ly;
% end
% 
% alltrain(:,yindex) = [];
% test = alltrain;
                  