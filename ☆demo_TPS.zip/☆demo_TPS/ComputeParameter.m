function Cparameter = ComputeParameter(Image,ratio)
% Image = double(imread('cameraman.tif'));
operatorA =  [ 0 0 0 0 0 0; 0 0 0 0 0 0; 0 1 2 2 1 0; 0 -1 -2 -2 -1 0; 0 0 0 0 0 0; 0 0 0 0 0 0]; %%  0^{o}
operatorA = operatorA./12;
% % %
% operatorB = imrotate(operatorA,  45,'bicubic','crop') %%    45^{o}
% operatorC = imrotate(operatorA,  90,'bicubic','crop') %%    90^{o}
% operatorD = imrotate(operatorA, 135,'bicubic','crop') %%   135^{o}
% %
operatorB = [         
          0         0   -0.0040    0.0015   -0.0060         0
          0   -0.0079    0.0093    0.0881         0    0.0060
    -0.0040    0.0093    0.1720         0   -0.0881   -0.0015
     0.0015    0.0881         0   -0.1720   -0.0093    0.0040
    -0.0060         0   -0.0881   -0.0093    0.0079         0
          0    0.0060   -0.0015    0.0040         0         0];
% %
 operatorC = [         
         0         0         0         0         0         0
         0         0    0.0833   -0.0833         0         0
         0         0    0.1667   -0.1667         0         0
         0         0    0.1667   -0.1667         0         0
         0         0    0.0833   -0.0833         0         0
         0         0         0         0         0         0];
% %
operatorD = [
         0    0.0060   -0.0015    0.0040         0         0
   -0.0060         0   -0.0881   -0.0093    0.0079         0
    0.0015    0.0881         0   -0.1720   -0.0093    0.0040
   -0.0040    0.0093    0.1720         0   -0.0881   -0.0015
         0   -0.0079    0.0093    0.0881         0    0.0060
         0         0   -0.0040    0.0015   -0.0060         0];
% %

ImageA = imfilter(Image,operatorA,'replicate','same');%conv2(Image,operatorA,'same');
ImageB = imfilter(Image,operatorB,'replicate','same');%conv2(Image,operatorA,'same');
ImageC = imfilter(Image,operatorC,'replicate','same');%conv2(Image,operatorA,'same');
ImageD = imfilter(Image,operatorD,'replicate','same');%conv2(Image,operatorA,'same');

% %
Cparameter = 1./(1 + ratio.*sqrt(ImageA.^2 + ImageB.^2 + ImageC.^2 + ImageD.^2));
% %
kernel = fspecial('gaussian',[7 7],1);
Cparameter = imfilter(Cparameter,kernel,'replicate','same');



      